package bg.sofia.uni.fmi.mjt.photoalbum;

public class EOD {
    private boolean endOfDirectory;

    public EOD() {
        this.endOfDirectory = false;
    }

    public boolean isEndOfDirectory() {
        return endOfDirectory;
    }

    public void setEndOfDirectory(boolean endOfDirectory) {
        this.endOfDirectory = endOfDirectory;
    }
}
