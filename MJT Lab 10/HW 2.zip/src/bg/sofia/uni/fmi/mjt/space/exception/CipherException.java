package bg.sofia.uni.fmi.mjt.space.exception;

public class CipherException extends Exception {
    public CipherException(String s) {
        super(s);
    }
}
