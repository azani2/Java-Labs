package bg.sofia.uni.fmi.mjt.intelligenthome.center.comparator;

import bg.sofia.uni.fmi.mjt.intelligenthome.device.IoTDevice;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Comparator;

public class KWhComparator implements Comparator<IoTDevice> {

    @Override
    public int compare(IoTDevice firstDevice, IoTDevice secondDevice) {
        LocalDateTime now = LocalDateTime.now();
        long firstHours = Duration.between(firstDevice.getInstallationDateTime(), now).toHours();
        long secondHours = Duration.between(secondDevice.getInstallationDateTime(), now).toHours();
        double first = firstDevice.getPowerConsumption() * firstHours;
        double second = secondDevice.getPowerConsumption() * secondHours;

        if (first > second) {
            return 1;
        } else if (second > first) {
            return -1;
        }
        return 0;
    }

}
